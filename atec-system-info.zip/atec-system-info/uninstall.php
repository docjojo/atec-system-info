<?php
if (!defined('ABSPATH')) { exit(); }
wp_cache_delete('atec_wpsi_version');
?>