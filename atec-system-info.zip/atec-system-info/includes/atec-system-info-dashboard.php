<?php
if (!defined('ABSPATH')) { exit(); }

function atec_createTable($title,$arr,$valid): void
{		  
	if ($title!='') atec_little_block($title);
	echo '<table class="atec-table atec-table-td-first atec-table-tiny atec-mb-10">';
  	foreach ($arr as $key => $value) { if ((empty($valid) || in_array($key,$valid)) && $value!='' && (gettype($value)!='array' || !empty($value))) { echo '<tr><td>'.esc_attr($key),'</td><td>'.esc_attr($value),'</td></tr>'; } }
	echo '</table>';
}

class ATEC_wpsi_results { function __construct() {

$url		= atec_get_url();
$nonce	= wp_create_nonce(atec_nonce());
$nav 	= atec_clean_request('nav');	
if ($nav=='') $nav='Status';

echo '
<div class="atec-page">';
	atec_header(__DIR__,'wpsi','System Info');	

	echo '
	<div class="atec-main">';
		atec_progress();
	
		$licenseOk=atec_check_license()===true;
		$arr=['#square-h Status','#server Server','#php Environment','#php phpinfo()','#php php.ini','#php Extensions','#php Variables','#sliders wp-config.php'];
		if (!(str_starts_with(strtolower(PHP_OS_FAMILY),'win'))) $arr[]='#wrench .htaccess';
		if (function_exists('apache_get_modules')) $arr[]='#apache Apache';
		
		atec_nav_tab($url, $nonce, $nav, $arr, 4, !$licenseOk);
		echo '
		<div class="atec-g atec-border">';
			atec_flush();
			
			echo
			'<div class="atec-overflow">';
	
				if ($nav=='Info') { @require('atec-info.php'); new ATEC_info(__DIR__); }
				{
					if ($nav=='Status') { @require(__DIR__.'/atec-wpsi-systemStatus.php'); }
					elseif ($nav=='Server') { @require(__DIR__.'/atec-server-info.php'); }
					elseif ($nav=='Environment') { @require(__DIR__.'/atec-wpsi-parsePHPinfo.php'); }
					elseif ($nav=='phpinfo') { @require(__DIR__.'/atec-wpsi-phpinfo.php'); }
					elseif ($nav=='php_ini') 
					{ 
						if (atec_pro_feature('„php.ini“ lists all options of the php.ini file and their values')) 
						{ 
							atec_include_if_exists(__DIR__,'atec-wpsi-phpINI-pro.php');
							if (class_exists('ATEC_wpsi_phpINI')) new ATEC_wpsi_phpINI();
							else atec_missing_class_check();
						}
					}
					elseif ($nav=='Extensions') 
					{ 
						if (atec_pro_feature('„Extension“ lists all active PHP extensions and checks whether recommended extensions are installed. Also shows version numbers of important extensions')) 				
						{ 
							atec_include_if_exists(__DIR__,'atec-wpsi-parseExtensions-pro.php');
							if (class_exists('ATEC_parseExtensions')) new ATEC_parseExtensions();
							else atec_missing_class_check();
						}
					}
					elseif ($nav=='Variables') 
					{ 
						if (atec_pro_feature('„Variables“ lists all PHP server variables and their values')) 
						{ 
							atec_include_if_exists(__DIR__,'atec-wpsi-php-variables-pro.php');
							if (class_exists('ATEC_php_variables')) new ATEC_php_variables();
							else atec_missing_class_check();
						}
					}		
					elseif ($nav=='wp_config_php') 
					{ 
						if (atec_pro_feature('„WP-Config“ shows the content of the wordpress wp-config.php file')) 
						{ 
							atec_include_if_exists(__DIR__,'atec-parseWPconfig-pro.php');
							if (class_exists('ATEC_parseWPconfig')) new ATEC_parseWPconfig();
							else atec_missing_class_check();
						}
					}
					elseif ($nav=='_htaccess') 
					{ 
						if (atec_pro_feature('„.htaccess“ shows the content of the /.htaccess file')) 
						{ 
							atec_include_if_exists(__DIR__,'atec-wpsi-htaccessParser-pro.php');
							if (class_exists('ATEC_htaccess_parser')) new ATEC_htaccess_parser();
							else atec_missing_class_check();
						}
					}
					elseif ($nav=='Apache') { @require(__DIR__.'/atec-wpsi-apache.php'); }
				}

		echo '</div>
		</div>
	</div>
</div>';

@require('atec-footer.php');

}}

new ATEC_wpsi_results;
?>