<?php
if (!defined('ABSPATH')) { exit(); }

class ATEC_parseApache { 

function __construct() {	

atec_little_block('Apache Modules');

echo '
	<div class="atec-g atec-g-14 atec-overflow atec-border atec-bg-w">';
		$arr=apache_get_modules();
		natcasesort($arr);
		foreach ($arr as $a) 
		{ echo '<span class="atec-dilb" style="padding: 2px 5px; white-space:nowrap;">', esc_attr($a), '</span>'; }
echo '
	</div>';

}}

new ATEC_parseApache();
?>